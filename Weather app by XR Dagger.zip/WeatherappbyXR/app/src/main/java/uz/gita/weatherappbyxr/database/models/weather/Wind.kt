package uz.gita.weatherappbyxr.database.models.weather

data class Wind(
    val speed: Double,
    val deg: Long
)