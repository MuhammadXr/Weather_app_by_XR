package uz.gita.weatherappbyxr.database.models.weather

data class Clouds(
    val all: Long
)