package uz.gita.weatherappbyxr.database.models.weather

data class Coord(
    val lon: Double,
    val lat: Double
)